//
//  OrderFoodViewController.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-07-27.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit

class OrderFoodViewController: UIViewController {
    
   
    var name: String!
    var mobile :Int64!
    var home : String!
    
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var amount: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var comment: UITextField!
    @IBOutlet weak var datepicker: UIDatePicker!
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var category: UISegmentedControl!
    @IBOutlet weak var kind: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()

//     let getInfo = DatabaseHelper.instance.getAllInfo()
//
//     username.text = (getInfo.2)
//     address.text = (getInfo.3)
 }
    
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func orderfood(_ sender: Any) {
        
                name = username.text
                 mobile = (Int64)(phone.text!)
                 home = address.text
                let Amount = (Float)(amount.text!)
                let comments = comment.text
                let type = kind.titleForSegment(at: kind.selectedSegmentIndex)
                let cat = category.titleForSegment(at: category.selectedSegmentIndex)
                let dateFormatter = DateFormatter()
                dateFormatter.dateStyle = DateFormatter.Style.short
                dateFormatter.timeStyle = DateFormatter.Style.short
                let strDate = dateFormatter.string(from: datepicker.date)
               
        
        if (mobile == nil || home!.isEmpty || amount.text!.isEmpty || type!.isEmpty||cat!.isEmpty||strDate.isEmpty) {
                    displayAlertMessages(userMessages: "All Fields Are Required");
                              return;
               }
        
        
        
        
        DatabaseHelper.instance.orderdetail(at: comments!, at: type!, at: home!, at: name!, at: cat!, at: datepicker.date, at: mobile!, at: Amount!)

               
        //
                
                
                
        
        
    }
    
    func displayAlertMessages(userMessages:String){
        var myAlert = UIAlertController(title: "Alert", message: userMessages, preferredStyle: UIAlertController.Style.alert);
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil);
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
    }
    
    
    @IBAction func availableitems(_ sender: Any) {
        
        name = username.text
        mobile = (Int64)(phone.text!)
        home = address.text
        print(name);
        print(mobile);
        print(home)
        UserDefaults.standard.set(name, forKey: "name")
         UserDefaults.standard.set(mobile, forKey: "mobile")
         UserDefaults.standard.set(home, forKey: "home")
        
        if let storyboard = self.storyboard {
                            let newViewController = storyboard.instantiateViewController(withIdentifier: "available")
            self.present(newViewController, animated: true, completion: nil)
                        }
        
    }
    
    
}
