//
//  OrderCell.swift
//  FoodDonation
//
//  Created by Sidharth Mehta on 11/08/20.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit

class OrderCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var amount: UILabel!
    
    @IBOutlet weak var date: UILabel!
    
    @IBOutlet weak var address: UILabel!
    
}
