import SideMenu
import UIKit
import NotificationBannerSwift

class SideMenu1: UIViewController, MenuControllerDelegate {

    private var sideMenu: SideMenuNavigationController?
    
    var x = 0;
   
    @IBAction func started(_ sender: UIButton) {
        if let storyboard = self.storyboard {
            let newViewController = storyboard.instantiateViewController(withIdentifier: "Do")
            self.present(newViewController, animated: true, completion: nil)
            
            
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        let menu = MenuController(with:[ "Home", "Profile","Donation-Order", "Location", "Order-Info", "Donation-Requests", "Logout"])
        menu.delegate = self
        sideMenu = SideMenuNavigationController(rootViewController: menu)
       
        sideMenu?.leftSide = true
        SideMenuManager.default.leftMenuNavigationController = sideMenu
        SideMenuManager.default.addPanGestureToPresent(toView: view)
    }
    
    @IBAction func didTapMenuButton(){
        present(sideMenu!, animated: true)
        
    }
    func didSelectMenuItem(named: String) {
        sideMenu?.dismiss(animated: true, completion: { [weak self] in
            if named == "Home"{
                
                
            }
            else if named == "Profile" {
                if let storyboard = self?.storyboard {
                     let newViewController = storyboard.instantiateViewController(withIdentifier: "UserViewController")
                     self?.present(newViewController, animated: true, completion: nil)
                 }
            }
                
                else if named == "Location" {
                    if let storyboard = self?.storyboard {
                         let newViewController = storyboard.instantiateViewController(withIdentifier: "LocationViewController")
                         self?.present(newViewController, animated: true, completion: nil)
                     }
                }
                
                
                
            else if named == "Donation-Order"{
                if let storyboard = self?.storyboard {
                    let newViewController = storyboard.instantiateViewController(withIdentifier: "Do")
                    self?.present(newViewController, animated: true, completion: nil)
                }
                
            }
                else if named == "Donation-Requests"
            {
                let donationinfo = DatabaseHelper.instance.getDonationInfo();
                if((donationinfo.0) == "" && self!.x==0)
                {
                    
                    let banner = NotificationBanner(title: "No Donation", subtitle:"Lets Wait SomeOne Will Come" , leftView: nil, rightView: nil, style: .info, colors: nil)
                    banner.show()
                    
                }
                else
                {
                    self!.x = 1;
                 if let storyboard = self?.storyboard {
                                   let newViewController = storyboard.instantiateViewController(withIdentifier: "summery")
                                   self?.present(newViewController, animated: true, completion: nil)
                    
                
            }
                }
            }
                
                else if named == "Order-Info"
                          {
                              let donationinfo = DatabaseHelper.instance.getAllorders();
                            if((donationinfo.6) == nil && self!.x==0)
                              {
                                  
                                  let banner = NotificationBanner(title: "No Order", subtitle:"Lets Wait SomeOne Will Donate" , leftView: nil, rightView: nil, style: .info, colors: nil)
                                  banner.show()
                                  
                              }
                              else
                              {
                                  self!.x = 1;
                               if let storyboard = self?.storyboard {
                                                 let newViewController = storyboard.instantiateViewController(withIdentifier: "ordersummery")
                                                 self?.present(newViewController, animated: true, completion: nil)
                                  
                              
                          }
                              }
                
            }
                else if named == "Logout"{
                
                
                
                
                UserDefaults.standard.set(false,forKey: "isuserloggedin");
                UserDefaults.standard.synchronize();
                if let storyboard = self?.storyboard {
                                   let newViewController = storyboard.instantiateViewController(withIdentifier: "login")
                                   self?.present(newViewController, animated: true, completion: nil)
                               }
                 self?.view.backgroundColor = .white
            }
            
        })
       }

}
protocol MenuControllerDelegate {
    func didSelectMenuItem(named: String)
}

class MenuController: UITableViewController {
    
    public var delegate: MenuControllerDelegate?
    
    private let menuItems: [String]
    private let color = UIColor(red: 33/255.0, green: 33/255.0, blue: 33/255.0, alpha: 1)
    
    init(with menuItems: [String]) {
        self.menuItems = menuItems
        super.init(nibName: nil, bundle: nil)
    
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = color
        view.backgroundColor = color
    }
 
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = menuItems[indexPath.row]
        cell.textLabel?.textColor = .white
        cell.backgroundColor = color
        cell.contentView.backgroundColor = color
        return cell
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let selectedItem = menuItems[indexPath.row]
        delegate?.didSelectMenuItem(named: selectedItem)
        
    }
    
    }



