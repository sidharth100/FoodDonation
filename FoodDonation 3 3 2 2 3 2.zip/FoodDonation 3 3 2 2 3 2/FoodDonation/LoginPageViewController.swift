//
//  LoginPageViewController.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-07-21.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit
import CoreData

class LoginPageViewController: UIViewController {

    @IBOutlet weak var userPassword: UITextField!
    @IBOutlet weak var userEmail: UITextField!
    var email,name,address,password :String!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      //  self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "login.jpg") ?? nil)!)
        // Do any additional setup after loading the view.
    }
    

    @IBAction func LoginButton(_ sender: Any) {
        
        let UserEmail = userEmail.text;
        let Password = userPassword.text;
        
        let getInfo = DatabaseHelper.instance.getAllInfo()
        
        email = (getInfo.0)
        password = (getInfo.1)
       
        
        print(UserEmail!)
        print(email ?? "pc")
        
        if(UserEmail==email)
        {
            print(Password!)
            print(email!)
            print(password!)
            
            if(Password==password)
            {
                print("mc")
                 UserDefaults.standard.set(true,forKey:"isuserloggedin");
                UserDefaults.standard.synchronize();
                self.performSegue(withIdentifier: "FoodApp", sender: nil)
                
                
            }
            displayAlertMessages(userMessages: "Password galat bc");
        }
        else if((UserEmail=="admin") && (Password=="admin")){
                    UserDefaults.standard.set(true,forKey:"isuserloggedin");
                    UserDefaults.standard.synchronize();
                    
            if let storyboard = self.storyboard {
                               let newViewController = storyboard.instantiateViewController(withIdentifier: "Admin")
                self.present(newViewController, animated: true, completion: nil)
                           }
                    
                }
        else{
            displayAlertMessages(userMessages: "Wrong Username and Password");
        }
    }
    
    func displayAlertMessages(userMessages:String){
        var myAlert = UIAlertController(title: "Alert", message: userMessages, preferredStyle: UIAlertController.Style.alert);
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil);
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
