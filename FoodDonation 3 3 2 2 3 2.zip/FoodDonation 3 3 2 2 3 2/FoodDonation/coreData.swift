//
//  coreData.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-07-26.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import Foundation
import CoreData
import UIKit
class DatabaseHelper {
    var image : Data!
    var email : String!
    var password : String!
    var username :String!
    var address : String!
    var phone : Int64!
    var comment : String!
    var amount : Float!
    var kind : String!
    var cat : String!
    var date : Date!
    
    
    
    
    static let instance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func saveImageCoreData(at imgData: Data , at email: String , at password: String , at address: String , at name:String ) {
        
            let entity = NSEntityDescription.insertNewObject(forEntityName: "Entity", into: context) as! Entity
            entity.img = imgData
            entity.email = email
            entity.address = address
            entity.password = password
            entity.name = name
            do {
                try context.save()
            }catch let error{
                print(error.localizedDescription)
            }
        
       
        
        
    }
    
    
    func userdetail(at imgData: Data , at email: String , at password: String , at address: String , at name:String, at phone :Int) {
           
               let entity = NSEntityDescription.insertNewObject(forEntityName: "UserDetail", into: context) as! UserDetail
               entity.img = imgData
               entity.email = email
               entity.address = address
               entity.password = password
               entity.name = name
               entity.phone = Int64(phone)
               do {
                   try context.save()
               }catch let error{
                   print(error.localizedDescription)
               }
           
          
           
           
       }
    
    func saveImageCouserdetailreData(at imgData: Data , at email: String , at password: String , at address: String , at name:String ) {
          
              let entity = NSEntityDescription.insertNewObject(forEntityName: "Entity", into: context) as! Entity
              entity.img = imgData
              entity.email = email
              entity.address = address
              entity.password = password
              entity.name = name
              do {
                  try context.save()
              }catch let error{
                  print(error.localizedDescription)
              }
          
         
          
          
      }
    
    
    
    func saveEntity2(at imgData: Data , at comments: String , at amount: Float , at address: String , at name:String , at kind : String, at cat : String, at phone : Int,at time : Date) {
         
          
               let entity = NSEntityDescription.insertNewObject(forEntityName: "EntityDonate", into: context) as! EntityDonate
               entity.img2 = imgData
               entity.comments = comments
               entity.address = address
               entity.amount = amount
               entity.phone = Int64(Int(phone))
               entity.time = time
               entity.raw = kind
               entity.name = name
               entity.veg = cat
        
               do {
                   try context.save()
                print("DATA SAVED")
               }catch let error{
                   print(error.localizedDescription)
               }
           
          
           
           
           
       }
    
    
    func orderdetail( at comments: String , at type: String , at address: String , at name:String,at cat: String , at date: Date,  at phone :Int64, at amount : Float) {
              
                  let entity = NSEntityDescription.insertNewObject(forEntityName: "OrderFood", into: context) as! OrderFood
        
                  entity.comment = comments
                  entity.type = type
                  entity.address = address
                  entity.cat = cat
                  entity.name = name
                  entity.date = date
                  entity.amount = amount
                  entity.phone = Int64(phone)
                  do {
                      try context.save()
                  }catch let error{
                      print(error.localizedDescription)
                  }
              
             
              
              
          }
    
    
    
    
    func getAllImage()-> Data{
        
        let context = (UIApplication.shared.delegate as!AppDelegate).persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Entity")
        request.returnsObjectsAsFaults = false;
        do{
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject]
            {
                 image   = data.value(forKey: "img")as? Data
               
            }
        } catch{
            print("Failed")
        }
        return image
        
}
    func getAllInfo() -> (String?,String?,String?,String?,Data?) {
        let context = (UIApplication.shared.delegate as!AppDelegate).persistentContainer.viewContext
               let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Entity")
               request.returnsObjectsAsFaults = false;
               do{
                   let result = try context.fetch(request)
                   for data in result as! [NSManagedObject]
                   {
                       email   = data.value(forKey: "email")as? String
                       password = data.value(forKey: "password")as? String
                       username = data.value(forKey: "name")as? String
                       address = data.value(forKey: "address")as? String
                    image = data.value(forKey: "img")as? Data
                       
                   }
               } catch{
                   print("Failed")
               }
        return (email , password , username , address,image) ;
    }
    
    func getAllDonation() -> (String?,String?,String?,String?,String?,Date?,Float?,Data?,Int64?) {
        let context = (UIApplication.shared.delegate as!AppDelegate).persistentContainer.viewContext
               let request = NSFetchRequest<NSFetchRequestResult>(entityName: "EntityDonate")
               request.returnsObjectsAsFaults = false;
               do{
                   let result = try context.fetch(request)
                   for data in result as! [NSManagedObject]
                   {
                       image   = data.value(forKey: "img2")as? Data
                       username = data.value(forKey: "name")as? String
                       phone = data.value(forKey: "phone")as? Int64
                       kind = data.value(forKey: "raw")as? String
                    cat = data.value(forKey: "veg")as? String
                    date = data.value(forKey: "time")as? Date
                    address = data.value(forKey: "address")as? String
                    amount = data.value(forKey: "amount")as? Float
                       comment = data.value(forKey: "comments")as? String
                   }
               } catch{
                   print("Failed")
               }
        return (username , address , kind , cat,comment,date,amount,image,phone) ;
    }
    
    func getAllorders() -> (String?,String?,String?,String?,String?,Date?,Float?,Int64?) {
        let context = (UIApplication.shared.delegate as!AppDelegate).persistentContainer.viewContext
               let request = NSFetchRequest<NSFetchRequestResult>(entityName: "OrderFood")
               request.returnsObjectsAsFaults = false;
               do{
                   let result = try context.fetch(request)
                   for data in result as! [NSManagedObject]
                   {
                      // image   = data.value(forKey: "img2")as? Data
                       username = data.value(forKey: "name")as? String
                       phone = data.value(forKey: "phone")as? Int64
                       kind = data.value(forKey: "type")as? String
                    cat = data.value(forKey: "cat")as? String
                    date = data.value(forKey: "date")as? Date
                    address = data.value(forKey: "address")as? String
                    amount = data.value(forKey: "amount")as? Float
                       comment = data.value(forKey: "comment")as? String
                   }
               } catch{
                   print("Failed")
               }
        return (username , address , kind , cat,comment,date,amount,phone) ;
    }
    
    
    
    
    
    func getDonationInfo() -> (String?,String?,Int64,Data?) {
        let context = (UIApplication.shared.delegate as!AppDelegate).persistentContainer.viewContext
               let request = NSFetchRequest<NSFetchRequestResult>(entityName: "DonationInfo")
               request.returnsObjectsAsFaults = false;
               do{
                   let result = try context.fetch(request)
                   for data in result as! [NSManagedObject]
                   {
                       username = data.value(forKey: "name")as? String
                       address = data.value(forKey: "address")as? String
                    image = data.value(forKey: "img")as? Data
                    phone = data.value(forKey: "phone") as? Int64
                       
                   }
                if(username == nil || address == nil || image == nil || phone == nil )
                {
                    username = ""
                    address = ""
                    phone = 0
                    
                }
               } catch{
                   print("Failed")
               }
        return (username! , address! ,phone!,image!) ;
    }
    
    
    
    func saveavaibleitem(at imgData: Data ,  at address: String , at name:String , at phone:Int64) {
           
               let entity = NSEntityDescription.insertNewObject(forEntityName: "DonationInfo", into: context) as! DonationInfo
               entity.img = imgData
               entity.address = address
               entity.name = name
               entity.phone = phone
               do {
                   try context.save()
               }catch let error{
                   print(error.localizedDescription)
               }
           
          
           
           
       }
    
    
    
}

