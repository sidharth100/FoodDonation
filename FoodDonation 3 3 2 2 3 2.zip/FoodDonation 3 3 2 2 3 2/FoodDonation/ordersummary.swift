//
//  ordersummary.swift
//  FoodDonation
//
//  Created by Vaibhav Dutt on 2020-08-11.
//  Copyright © 2020 Vaibhav Dutt. All rights reserved.
//

import UIKit
import CoreData
class ordersummary: UIViewController {
    var x : Date!
    @IBOutlet weak var comment: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var amount: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var imgview: UIImageView!
    
    @IBOutlet weak var kind: UILabel!
    
    
    @IBOutlet weak var cat: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let donation = DatabaseHelper.instance.getAllorders()
               
               
               name.text = donation.0
        address.text = donation.1
        kind.text = donation.2
        cat.text = donation.3
        comment.text = donation.4
        x =  donation.5
        amount.text = String(donation.6!)
        phone.text = String(donation.7!)
        
               
               let formatter = DateFormatter()
               // initially set the format based on your datepicker date / server String
               formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

               let myString = formatter.string(from: x) // string purpose I add here
               // convert your string to date
               let yourDate = formatter.date(from: myString)
               //then again set the date format whhich type of output you need
               formatter.dateFormat = "dd-MMM-yyyy HH:mm:ss"
               // again convert your date to string
               let myStringafd = formatter.string(from: yourDate!)
               time.text = myStringafd
               print(myStringafd)
        
        let img = DatabaseHelper.instance.getAllInfo()
        imgview.image = UIImage(data: img.4!)
    }
    

    @IBAction func deleteorder(_ sender: Any) {
                let context = ( UIApplication.shared.delegate as! AppDelegate ).persistentContainer.viewContext
        
    let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "OrderFood")
                       let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
                       do
                       {
                           try context.execute(deleteRequest)
                           try context.save()
                        print("hogaya delete bc")
                       }
                       catch
                       {
                           print ("There was an error")
                        
                }
                
        self.performSegue(withIdentifier: "ordersummary", sender: nil)
        
    }
    
}
